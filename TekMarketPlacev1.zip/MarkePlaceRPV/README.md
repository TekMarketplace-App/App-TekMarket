# MakerPriceUFRPE
Repositório do projeto MakerPrice, realizado para a disciplina de MPOO, no curso de Bacharelado em Sistemas de Informação.

Este projeto consiste em um App para busca e comparação de preços de componentes eletrônicos e ferramentas maker.

Também é possível cadastrar projetos realizados com tais componentee/ferramentas.

# Equipe
- Daniel Carvalho
- João Vitor
- Jonathan Henrique
- Udney Carvalho
- Vinícius Mateus
