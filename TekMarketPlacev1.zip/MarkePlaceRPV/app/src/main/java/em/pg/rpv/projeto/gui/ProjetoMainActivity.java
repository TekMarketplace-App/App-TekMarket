package em.pg.rpv.projeto.gui;

import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;

import em.pg.rpv.R;
import em.pg.rpv.componente.dominio.ComponenteLoja;
import em.pg.rpv.componente.dominio.ComponenteQuantidade;
import em.pg.rpv.componente.gui.ComponenteActivity;
import em.pg.rpv.componente.negocio.Comparador;
import em.pg.rpv.componente.negocio.ComponenteService;
import em.pg.rpv.infra.ComponenteLojaListAdapter;
import em.pg.rpv.infra.Converter;
import em.pg.rpv.infra.GuiUtil;
import em.pg.rpv.infra.Sessao;
import em.pg.rpv.projeto.dominio.Projeto;
import em.pg.rpv.projeto.negocio.ProjetoService;
import em.pg.rpv.usuario.dominio.PessoaFisica;

public class ProjetoMainActivity extends AppCompatActivity {
    private ProjetoService projetoService = new ProjetoService(this);
    private ComponenteService componenteService = new ComponenteService(this);
    private Sessao sessao = Sessao.getInstancia();
    private Projeto projeto;
    private Converter converter = Converter.getInstancia();
    private Comparador comparador = new Comparador(this);
    private GuiUtil guiUtil = GuiUtil.getGuiUtil();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_projeto_main);

        PessoaFisica criador = sessao.getPessoaFisica();
        long idCriador = criador.getID();

        projeto = sessao.getProjeto();

        ImageView imageView = (ImageView) findViewById(R.id.projeto_imagem_principal);
        TextView textViewNome = (TextView) findViewById(R.id.nome_projeto_main);
        TextView textViewDescricao = (TextView) findViewById(R.id.descricao_projeto_main);
        TextView textViewPlataforma = (TextView) findViewById(R.id.plataforma_projeto_main);
        TextView textViewAplicacao = (TextView) findViewById(R.id.aplicacao_projeto_main);
        TextView textViewPrecoTotal = (TextView) findViewById(R.id.preco_total_projeto);
        ListView listViewComponentes = (ListView) findViewById(R.id.lista_componentes_projeto);

        textViewNome.setText(projeto.getNome());
        textViewDescricao.setText(projeto.getDescricao());
        textViewPlataforma.setText(projeto.getPlataforma());
        textViewAplicacao.setText(projeto.getAplicacao());

        ArrayList<ComponenteQuantidade> listaComponenteQuantidade = projeto.getComponentes();
        ArrayList<ComponenteLoja> listaComponenteLoja = (ArrayList<ComponenteLoja>) comparador.getPrecoProjeto(projeto);
        ComponenteLojaListAdapter componenteLojaAdapter = new ComponenteLojaListAdapter(this, 0, listaComponenteLoja, listaComponenteQuantidade);
        listViewComponentes.setAdapter(componenteLojaAdapter);
        listViewComponentes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ComponenteLoja componenteLoja = (ComponenteLoja) parent.getAdapter().getItem(position);

                Intent intent = new Intent(ProjetoMainActivity.this, ComponenteActivity.class);
                intent.putExtra("selected-item", String.valueOf(componenteLoja.getComponente().getId()));
                startActivity(intent);
            }
        });

        double precoTotal = 0;
        DecimalFormat df = new DecimalFormat("0.00");//
        DecimalFormatSymbols dfSymbols = new DecimalFormatSymbols();//
        dfSymbols.setDecimalSeparator(',');//
        df.setDecimalFormatSymbols(dfSymbols);
        int quantidadeComponenteLoja = listaComponenteLoja.size();
        for (int i = 0 ; i < quantidadeComponenteLoja ; i++) {
            double preco = listaComponenteLoja.get(i).getPreco();
            int quantidade = listaComponenteQuantidade.get(i).getQuantidade();
            precoTotal += preco * quantidade;
        }
        textViewPrecoTotal.setText("R$ " + String.valueOf(df.format(precoTotal)));

        String imagemPrincipal = projeto.getImagens().get(0);
        Bitmap imagem = converter.StringToBitMap(imagemPrincipal);
        imageView.setImageBitmap(imagem);

    }

    public void onButtonClickProjeto(View v){

        if (v.getId() == R.id.projeto_imagem_principal){
            Intent intent= new Intent(this, ListaImagensProjetoActivity.class);
            sessao.setProjeto(projeto);
            startActivity(intent);
        }
    }

}
