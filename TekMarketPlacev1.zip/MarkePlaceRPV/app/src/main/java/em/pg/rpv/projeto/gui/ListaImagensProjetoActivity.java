package em.pg.rpv.projeto.gui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import em.pg.rpv.R;
import em.pg.rpv.infra.ProjetoImagemListAdapter;
import em.pg.rpv.infra.Sessao;

public class ListaImagensProjetoActivity extends AppCompatActivity {
    private Sessao sessao = Sessao.getInstancia();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_imagens_projeto);

        ProjetoImagemListAdapter projetoImagemAdapter;
        ListView listView = (ListView) findViewById(R.id.listaImagensProjeto);
        projetoImagemAdapter = new ProjetoImagemListAdapter(this, 0, sessao.getProjeto().getImagens());
        listView.setAdapter(projetoImagemAdapter);
    }
}
